module.exports=function sortingarray(unsorted){
    let sorted=unsorted.slice();
    return sorted.sort((a,b)=>a-b);

}