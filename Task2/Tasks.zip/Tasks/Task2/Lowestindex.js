module.exports=function Highestindex(unsorted,sorted){
    return unsorted.indexOf(sorted[0]);
}